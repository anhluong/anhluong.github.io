//
//  CSColor.m
//  Colors
//

#import "CSColor.h"

#pragma mark -
#pragma mark Private Interface
@interface CSColor ()
@end

#pragma mark -
@implementation CSColor

#pragma mark Class Methods
+ (void) componentsOfColor:(UIColor*)color red:(float*)red green:(float*)green blue:(float*)blue alpha:(float*)alpha
{
    // Check the component count of the color space assocated with the CGColor (pattern and index colors are unsupported)
	int componentCount = CGColorGetNumberOfComponents([color CGColor]);
    if (componentCount < 2)
        return;
    
    // Pull the color components out of the CGColor
    // NOTE: Assumes that the color space is a grayscale color space or an RGB color space 
    // (which seems to always be true in a typical UIColor)
	const float* components = CGColorGetComponents([color CGColor]);
	if (red != NULL)
        *red = componentCount == 4 ? components[0] : components[0];
	if (green != NULL)
        *green = componentCount == 4 ? components[1] : components[0];
	if (blue != NULL)
        *blue = componentCount == 4 ? components[2] : components[0];
	if (alpha != NULL)
        *alpha = componentCount == 4 ? components[3] : components[1];
}

+ (void) componentsOfColor:(UIColor*)color hue:(float*)hue saturation:(float*)saturation value:(float*)value alpha:(float*)alpha
{
    // Get the RGBA representation of the color
    // NOTE: Alpha value comes straight across
    float red = 0.0f;
    float green = 0.0f;
    float blue = 0.0f;
    [CSColor componentsOfColor:color red:&red green:&green blue:&blue alpha:alpha];

	// Hue is calculated based on the max of red, green, and blue and ranges from 0.0 -> 1.0
    float h = 0.0f;
    float maxChannel = fmax(red, fmax(green, blue));
    float minChannel = fmin(red, fmin(green, blue));
    if (maxChannel == minChannel)
        h = 0.0f;
    else if (maxChannel == red)
        h = 0.166667f * (green - blue) / (maxChannel - minChannel) + 0.000000f;
    else if (maxChannel == green)
        h = 0.166667f * (blue - red) / (maxChannel - minChannel) + 0.333333f;
    else if (maxChannel == blue)
        h = 0.166667f * (red - green) / (maxChannel - minChannel) + 0.666667f;
    else
        h = 0.0f;
    
    // Corrects region 6 hue crossover
    if (h < 0.0f)
        h += 1.0f;
    
    // Save calculated hue
    if (hue != NULL)
        *hue = h;
        
	// Saturation ranges from 0.0 -> 1.0
    if (saturation != NULL)
        *saturation = fmax(0.0f, 1.0f - minChannel / maxChannel);
	
	// Value ranges from 0.0 -> 1.0
	if (value != NULL)
        *value = maxChannel;
}

+ (void) addRoundedRect:(CGRect)rect radiusPercent:(float)radiusPercent
{
	CGContextRef context = UIGraphicsGetCurrentContext();
    
	CGFloat radius = fminf(rect.size.width, rect.size.height) * radiusPercent;
	CGFloat minX = CGRectGetMinX(rect);
    CGFloat midX = CGRectGetMidX(rect);
    CGFloat maxX = CGRectGetMaxX(rect);
    CGFloat minY = CGRectGetMinY(rect);
    CGFloat midY = CGRectGetMidY(rect);
    CGFloat maxY = CGRectGetMaxY(rect);
    CGContextMoveToPoint(context, minX, midY);
    CGContextAddArcToPoint(context, minX, minY, midX, minY, radius);
    CGContextAddArcToPoint(context, maxX, minY, maxX, midY, radius);
    CGContextAddArcToPoint(context, maxX, maxY, midX, maxY, radius);
    CGContextAddArcToPoint(context, minX, maxY, minX, midY, radius);
    CGContextClosePath(context);
}

@end
