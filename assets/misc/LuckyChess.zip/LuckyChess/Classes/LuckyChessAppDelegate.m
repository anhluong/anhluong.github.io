//
//  LuckyChessAppDelegate.m
//  LuckyChess
//
//  Created by Anh Luong on 4/22/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "LuckyChessAppDelegate.h"
#import "EAGLView.h"

@interface LuckyChessAppDelegate()<WelcomeViewDelegate, HelpDelegate, BetViewControllerDelegate, StorageDelegate, SettingsViewDelegate>
@end

#pragma mark -
@implementation LuckyChessAppDelegate

#pragma mark Constructors
- (void) applicationDidFinishLaunching:(UIApplication*)application 
{
    // Create window and OpenGL view
	_window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	//_glView = [[EAGLView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	//[_window addSubview:_glView];
	[_window makeKeyAndVisible];
	
	_settings = [[Storage alloc] init];
	_settings.delegate = self;
	
	_welcomeView = [[WelcomeView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	_welcomeView.delegate = self;
	
	_betView = [[BetViewController alloc] initWithFrame:[[UIScreen mainScreen] bounds] settings:_settings];
	_betView.delegate = self;
	
	_settingsView = [[SettingsView alloc] initWithFrame:[[UIScreen mainScreen] bounds] settings:_settings];
	_settingsView.delegate = self;
	
	_helpView = [[Help alloc] init];
	_helpView.delegate = self;
	
	UIViewController* welcomeViewController = [[UIViewController alloc] init];
	[welcomeViewController setView:_welcomeView];
	
	_navigationController = [[UINavigationController alloc] initWithRootViewController:welcomeViewController];
	[_navigationController setNavigationBarHidden:YES];
	[_window addSubview:[_navigationController view]];
}

- (void) applicationWillTerminate:(UIApplication*)application 
{
	[_settings release];
	[_welcomeView release];
	[_betView release];
	[_settingsView release];
	[_helpView release];
	[_window release];
	[_glView release];
}

- (void) play
{
	[_navigationController pushViewController:_betView animated:TRUE];
}

- (void) setting
{
	[_navigationController pushViewController:_settingsView animated:TRUE];
	[_navigationController setNavigationBarHidden:NO animated:TRUE];
}

- (void) help
{
	[_navigationController pushViewController:_helpView animated:TRUE];
	[_navigationController setNavigationBarHidden:NO animated:TRUE];
}

- (void) menu
{
	[_navigationController popToRootViewControllerAnimated:TRUE];
	[_navigationController setNavigationBarHidden:YES animated:TRUE];
}

- (void) playersChanged:(int)num
{
	[_betView setNumOfPlayers:num];
}

- (void) colorIsChanged:(UIColor*) color
{	
	[_betView setBackground:color];
}
@end
