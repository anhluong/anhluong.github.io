//
//  CSColor.h
//  Colors
//

#import <Foundation/Foundation.h>

@interface CSColor : NSObject 
{
	
}

+ (void) componentsOfColor:(UIColor*)color red:(float*)red green:(float*)green blue:(float*)blue alpha:(float*)alpha;
+ (void) componentsOfColor:(UIColor*)color hue:(float*)hue saturation:(float*)saturation value:(float*)value alpha:(float*)alpha;
+ (void) addRoundedRect:(CGRect)rect radiusPercent:(float)radiusPercent;

@end
