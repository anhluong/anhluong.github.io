//
//  SettingsView.m
//  LuckyChess
//
//  Created by Anh Luong on 4/26/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SettingsView.h"

#pragma mark -
#pragma mark Private Interface
@interface SettingsView ()<UITableViewDelegate, ChooserViewControllerDelegate>
@end

#pragma mark -
@implementation SettingsView

#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame settings:(Storage*)settings
{
    self = [super init];
    if (self == nil)
        return nil;
    
	_settings = [[settings retain] autorelease];
	_backgroundColorChooser = [[ChooserViewController alloc] initWithFrame:frame];
	_backgroundColorChooser.delegate = self;
	
    return self;
}

- (void) dealloc
{
    [super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

- (UITableView*) contentView
{
    return (UITableView*)[self view];
}

#pragma mark -
#pragma mark Methods
#pragma mark UIViewController Overrides
- (void) loadView
{
    // Create a table view as the managed view of this controller
    [self setView:[[[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped] autorelease]];
}

- (void) viewDidLoad
{
    // Setup the data source and delegate for the table view
    [[self contentView] setDataSource:_settings];
    [[self contentView] setDelegate:self];
	
	UIBarButtonItem* cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Back"
																	 style:UIBarButtonItemStyleBordered
																	target:self
																	action:@selector(handleBack:)];
	self.navigationItem.leftBarButtonItem = cancelButton;
	[cancelButton release];
}

- (void) handleBack:(id)sender
{
	[self.navigationController setNavigationBarHidden:YES animated:TRUE];
	[self.navigationController popViewControllerAnimated:YES];
}

- (void) tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath
{
	if ([indexPath section] == 0 && [indexPath row] == 1)
	{
		[self.navigationController presentModalViewController:_backgroundColorChooser animated:TRUE];
		[tableView deselectRowAtIndexPath:indexPath animated:TRUE];
	}
}

- (void) colorIsChanged:(UIColor*) color
{	
	[_delegate colorIsChanged:color];
	[self.navigationController dismissModalViewControllerAnimated:TRUE];
}

@end
