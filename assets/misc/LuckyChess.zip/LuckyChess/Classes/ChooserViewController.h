//
//  ChooserViewController.h
//  Shapes
//
//  Created by u0533327 on 3/11/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ChooserView.h"

@class ChooserViewController;

@protocol ChooserViewControllerDelegate
- (void) colorIsChanged:(UIColor*)color;
@end

@interface ChooserViewController : UIViewController
{
	ChooserView* _colorWheel;
	
	NSObject<ChooserViewControllerDelegate>* _delegate;
}

@property (assign) NSObject<ChooserViewControllerDelegate>* delegate;
- (void) setColor:(UIColor*)color;

@end
