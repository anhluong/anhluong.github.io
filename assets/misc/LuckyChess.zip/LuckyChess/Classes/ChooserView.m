//
//  ChooserView.m
//  Color Chooser
//
//  Created by Anh Luong on 2/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ChooserView.h"
#import "WheelView.h"
#import "SelectionView.h"

#pragma mark -
#pragma mark Private Interface
@interface ChooserView () <WheelViewDelegate, SelectionViewDelegate>
@end

#pragma mark -
@implementation ChooserView

#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self == nil)
        return nil;
	
	_color = [UIColor redColor];
	_previousColor = [UIColor whiteColor];
	
	//Create wheel view
	_wheelView = [[WheelView alloc] initWithFrame:CGRectZero];
	_wheelView.delegate = self;
	[_wheelView addTarget:self action:@selector(wheelColorChanged) forControlEvents:UIControlEventValueChanged];
	[self addSubview:_wheelView];

	_selector = [[SelectionView alloc] initWithFrame:CGRectZero];
	_selector.viewDelegate = self;
	[self addSubview:_selector];
	
	_previous = [[SelectionView alloc] initWithFrame:CGRectZero];
	_previous.viewDelegate = self;
	[self addSubview:_previous];
	
	float width = [self bounds].size.width;
	float height = [self bounds].size.height*0.75f;
	
	// Compare Title Label
	UILabel* _compareLabel = [[UILabel alloc] init];
	[_compareLabel setFrame:CGRectMake(width * 0.05f, height * 0.70f , width * 0.8f, height * 0.15f)];
	[_compareLabel setBackgroundColor:[UIColor clearColor]];
	[_compareLabel setText:@"Sat."];
	_compareLabel.font = [UIFont boldSystemFontOfSize:10];
	_compareLabel.textColor = [UIColor redColor];
	[self addSubview:_compareLabel];
	
	// Compare
	_compare = [[UISlider alloc] init];
	[_compare setFrame:CGRectMake(width * 0.15f, height * 0.70f , width * 0.7f, height * 0.15f)];
	[_compare addTarget:self action:@selector(changeCompare) forControlEvents:UIControlEventValueChanged];
	[_compare setMinimumValue:0.1f];
	[_compare setMaximumValue:1.0f];
	[self addSubview:_compare];
	
	// Value Title Label
	UILabel* _valueLabel = [[UILabel alloc] init];
	[_valueLabel setFrame:CGRectMake(width * 0.05f, height * 0.80f , width * 0.8f, height * 0.15f)];
	[_valueLabel setBackgroundColor:[UIColor clearColor]];
	[_valueLabel setText:@"Bright."];
	_valueLabel.font = [UIFont boldSystemFontOfSize:10];
	_valueLabel.textColor = [UIColor redColor];
	[self addSubview:_valueLabel];
	
	// Value Slider
	_value = [[UISlider alloc] init];
	[_value setFrame:CGRectMake(width * 0.15f, height * 0.80f , width * 0.7f, height * 0.15f)];
	[_value addTarget:self action:@selector(changeValue) forControlEvents:UIControlEventValueChanged];
	[_value setMinimumValue:0.1f];
	[_value setMaximumValue:1.0f];
	[self addSubview:_value];
	
	// Alpha Title Label
	UILabel* _alphaLabel = [[UILabel alloc] init];
	[_alphaLabel setFrame:CGRectMake(width * 0.05f, height * 0.90f , width * 0.8f, height * 0.15f)];
	[_alphaLabel setBackgroundColor:[UIColor clearColor]];
	[_alphaLabel setText:@"Alpha"];
	_alphaLabel.font = [UIFont boldSystemFontOfSize:10];
	_alphaLabel.textColor = [UIColor redColor];
	[self addSubview:_alphaLabel];
	
	// Alpha Slider
	_alpha = [[UISlider alloc] init];
	[_alpha setFrame:CGRectMake(width * 0.15f, height * 0.90f , width * 0.7f, height * 0.15f)];
	[_alpha addTarget:self action:@selector(changeAlpha) forControlEvents:UIControlEventValueChanged];
	[_alpha setMinimumValue:0.1f];
	[_alpha setMaximumValue:1.0f];
	[self addSubview:_alpha];
	
	// Button
	_store = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
	[_store setFrame:CGRectMake(width * 0.425f, height * 1.085f, width * 0.15f, height * 0.125f)];
	[_store setTitle:@"Set" forState:UIControlStateNormal];
	[_store addTarget:self action:@selector(store) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_store];
	
	//Set starting color
	[self setColor: _color];
    [self setPreviousColor: _previousColor];
    
    return self;
}

- (void) dealloc
{
    [_wheelView release];
	[_selector release];
	[_compare release];
	[_value release];
	[_alpha release];
	[_color release];
	[_previousColor release];
	[super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

- (UIColor*) color
{
    return _color;
}

- (void) setColor:(UIColor*)color
{
    [_color autorelease];
    _color = [color retain];
	
	[_selector setColor:color];
    [self setNeedsDisplay];
}

- (UIColor*) previousColor
{
    return _previousColor;
}

- (void) setPreviousColor:(UIColor*)color
{
    [_previousColor autorelease];
    _previousColor = [color retain];
	
	[_previous setColor:color];
    [self setNeedsDisplay];
}

#pragma mark -
#pragma mark Methods

#pragma mark -
#pragma mark UIView Overrides
- (void) layoutSubviews
{	
    //Calculate rectangles for subviews
	CGRect wheelFrame = CGRectZero;
    wheelFrame.origin.x = [self bounds].origin.x;
    wheelFrame.origin.y = [self bounds].origin.y;
    wheelFrame.size.width = [self bounds].size.width;
    wheelFrame.size.height = [self bounds].size.height * 0.5f;
	
	CGRect selector = CGRectZero;
    selector.origin.x = [self bounds].size.width * 0.60f;
    selector.origin.y = [self bounds].size.height * 0.85f;
    selector.size.width = [self bounds].size.width * 0.30f;
    selector.size.height = [self bounds].size.height * 0.10f;
	
	CGRect previous = CGRectZero;
    previous.origin.x = [self bounds].size.width * 0.10f;
    previous.origin.y = [self bounds].size.height * 0.85f;
    previous.size.width = [self bounds].size.width * 0.30f;
    previous.size.height = [self bounds].size.height * 0.10f;
    
	//Size subviews according to rectangles
    [_wheelView setFrame:wheelFrame];
    [_selector setFrame:selector];
	[_previous setFrame:previous];
	
	//Refresh color controls and reposition color selectors by calling setColor:
	[_wheelView setNeedsDisplay];
	[_selector setNeedsDisplay];
	[_previous setNeedsDisplay];
}

#pragma mark
- (void) changeCompare
{
	float hue = 0.0f;
	float saturation = 0.0f;
	float value = 0.0f;
	float alpha = 0.0f;
	
	[CSColor componentsOfColor:_color hue:&hue saturation:&saturation value:&value alpha:&alpha];
	[self setColor:[UIColor colorWithHue:hue saturation:[_compare value] brightness:value alpha:alpha]];
}

- (void) wheelColorChanged
{
	[self setColor:[_wheelView color]];
}

- (void) changeValue
{
	float hue = 0.0f;
	float saturation = 0.0f;
	float alpha = 0.0f;
	
	[CSColor componentsOfColor:_color hue:&hue saturation:&saturation value:NULL alpha:&alpha];
	[self setColor:[UIColor colorWithHue:hue saturation:saturation brightness:[_value value] alpha:alpha]];
}

- (void) changeAlpha
{
	float hue = 0.0f;
	float saturation = 0.0f;
	float value = 0.0f;
	
	[CSColor componentsOfColor:_color hue:&hue saturation:&saturation value:&value alpha:NULL];
	[self setColor:[UIColor colorWithHue:hue saturation:saturation brightness:value alpha:[_alpha value]]];
}

- (void) store
{
	[self setPreviousColor:_color];
	[_delegate colorChanged:_color];
}

@end
