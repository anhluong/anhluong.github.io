//
//  LuckyChessAppDelegate.h
//  LuckyChess
//
//  Created by Anh Luong on 4/22/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Storage.h"
#import "WelcomeView.h"
#import "SettingsView.h"
#import "Help.h"
#import "BetViewController.h"

@class EAGLView;

@interface LuckyChessAppDelegate : NSObject <UIApplicationDelegate> 
{
    UIWindow* _window;
    EAGLView* _glView;
	Storage* _settings;
	WelcomeView* _welcomeView;
	BetViewController* _betView;
	SettingsView* _settingsView;
	Help* _helpView;
	UINavigationController* _navigationController;
}

@end

