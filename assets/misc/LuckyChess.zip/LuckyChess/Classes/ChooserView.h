//
//  ChooserView.h
//  Color Chooser
//
//  Created by Anh Luong on 2/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WheelView.h"
#import "SelectionView.h"
#import "CSColor.h"

@class ChooserView;

@protocol ChooserViewDelegate
@optional -(void) colorChooser:(ChooserView*)colorChooser colorChanged:(UIColor*)color;
- (void) colorChanged:(UIColor*)color;
@end

@interface ChooserView : UIControl
{
	WheelView* _wheelView;
	SelectionView* _selector;
	SelectionView* _previous;
	
	UISlider* _value;
	UISlider* _alpha;
	UISlider* _compare;
	UIButton* _store;
	
	NSObject<ChooserViewDelegate>* _delegate;
	UIColor* _color;
	UIColor* _previousColor;
	
	CGPoint _touchPoint;

}

@property (retain) UIColor* color;
@property (assign) NSObject<ChooserViewDelegate>* delegate;
@property (retain) UIColor* previousColor;

@end
