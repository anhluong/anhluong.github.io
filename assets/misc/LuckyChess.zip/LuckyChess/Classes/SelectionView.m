//
//  SelectionView.m
//  Colors
//

#import "SelectionView.h"
#import "CSColor.h"

#define CSColorChooserSliderBorderWidth 4.0f
#define CSColorChooserSliderRoundedRectRadiusPercent 0.25f
#define CSColorChooserColorIndicatorWidth 2.0f

#pragma mark -
#pragma mark Private Interface
@interface SelectionView ()
- (void) calculateSliderRect;
@end

#pragma mark -
@implementation SelectionView

#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame 
{
    self = [super initWithFrame:frame];
	if (self == nil)
		return nil;
	
	[self setBackgroundColor:[UIColor lightGrayColor]];
	
	[self calculateSliderRect];
	
    return self;
}

- (void) dealloc 
{
	[self setViewDelegate:nil];
	
	[_color release];
	
	[super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize viewDelegate = _viewDelegate;

- (UIColor*) color
{
	return _color;
}
- (void) setColor:(UIColor*)color
{
	[_color autorelease];
    _color = [color retain];
	[self setNeedsDisplay];
}

#pragma mark -
#pragma mark Methods
- (void) calculateSliderRect
{
	//Calculate the rectangle into which the gradient will be drawn and selections will be based on
	_sliderRect = CGRectMake(
		[self bounds].origin.x + CSColorChooserSliderBorderWidth,
		[self bounds].origin.y + CSColorChooserSliderBorderWidth,
		[self bounds].size.width - CSColorChooserSliderBorderWidth * 2.0f,
		[self bounds].size.height - CSColorChooserSliderBorderWidth * 2.0f);
}

#pragma mark UIView Methods
- (void) setFrame:(CGRect)frame
{
    [super setFrame:frame];
    [self calculateSliderRect];
}

- (void) drawRect:(CGRect)rect 
{
    CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextSetFillColorWithColor(context, [[UIColor lightGrayColor] CGColor]);
	CGContextFillRect(context, [self bounds]);
    
	//Calculate the rectangle into which the gradient will be drawn
	[self calculateSliderRect];
	
	//Clip contents to rounded rect
	CGContextSaveGState(context);
	[CSColor addRoundedRect:_sliderRect radiusPercent:CSColorChooserSliderRoundedRectRadiusPercent];
	CGContextClip(context);

	//Fill control
	CGContextSetFillColorWithColor(context, [_color CGColor]);
	CGContextFillRect(context, _sliderRect);
	
	//Draw bounding rect
	CGContextRestoreGState(context);
	CGContextSetStrokeColorWithColor(context, [[UIColor blackColor] CGColor]);
	CGContextSetLineWidth(context, CSColorChooserSliderBorderWidth);
	[CSColor addRoundedRect:_sliderRect radiusPercent:CSColorChooserSliderRoundedRectRadiusPercent];
	CGContextStrokePath(context);
}

@end
