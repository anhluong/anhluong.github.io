//
//  BetViewController.h
//  LuckyChess
//
//  Created by Anh Luong on 4/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Storage.h";
#import "BetView.h";

@class BetViewController;

@protocol BetViewControllerDelegate
- (void) setting;
- (void) help;
- (void) menu;
@end


@interface BetViewController : UIViewController
{
	BetView* _betView;
	CGRect _frame;
	NSObject<BetViewControllerDelegate>* _delegate;
}

@property (assign) NSObject<BetViewControllerDelegate>* delegate;
- (id) initWithFrame:(CGRect)frame settings:(Storage*)settings;
- (void) setNumOfPlayers:(int)num;
- (void) setBackground:(UIColor*)color;

@end
