//
//  Help.h
//  LuckyChess
//
//  Created by Anh Luong on 4/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Help;

@protocol HelpDelegate
@end

@interface Help : UIViewController
{
	NSObject<HelpDelegate>* _delegate;
	UIWebView* _webView;
}

@property (assign) NSObject<HelpDelegate>* delegate;
@end
