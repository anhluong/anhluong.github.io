//
//  Help.m
//  LuckyChess
//
//  Created by Anh Luong on 4/25/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Help.h"

#pragma mark -
#pragma mark Private Interface
@interface Help ()
@end

#pragma mark -
@implementation Help

#pragma mark Constructors
- (id) init
{
    self = [super init];
    if (self == nil)
        return nil;
	
    return self;
}

- (void) dealloc
{
    [super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

- (UIWebView*) contentView
{
	return (UIWebView*)[self view];
}

#pragma mark -
#pragma mark Methods
#pragma mark UIViewController Overrides
- (void) loadView
{
	_webView = [[[UIWebView alloc] init] autorelease];
	[self setView:_webView];
}

- (void) viewDidLoad
{
	[[self contentView] setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
	
	NSString* helpHtmlString = 
    @"<html>"
    @"<head>"
    @"<title>Stuff Help</title>"
    @"<meta name =\"viewport\" content =\"user-scalable=no, width=320\" />"
    @"</head>"
    @"<body>"
    @"<h1 align=center>~ Help ~</h1>"
    @"<p align=left>+ Tap on money amount you wanna bet</p>"
    @"<p align=left>+ Tap on the item you wanna bet on</p>"
    @"<p align=left>+ Tap roll when you are done</p>"
    @"<p align=left>+ In case you don't like your bets, tap Clear</p>"
    @"<p align=left><br /></p>"
	@"<p align=center>Problems and Questions:</p>"
    @"<p align=center>MTP Corp.</p>"
    @"<p align=center>help@mtp.com</p>"
    @"<p align=center>801-999-8605</p>"
    @"<p align=center>Proof of Concepts</p>"
    @"</body>"
    @"</html>"
    @"";
	
	[[self contentView] loadHTMLString:helpHtmlString baseURL:nil];
	
	UIBarButtonItem* cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Back"
																	 style:UIBarButtonItemStyleBordered
																	target:self
																	action:@selector(handleBack:)];
	
	self.navigationItem.leftBarButtonItem = cancelButton;
	[cancelButton release];
}

- (void) handleBack:(id)sender
{
	[self.navigationController setNavigationBarHidden:YES animated:TRUE];
	[self.navigationController popViewControllerAnimated:YES];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
	return TRUE;
}

@end
