//
//  SettingsView.h
//  LuckyChess
//
//  Created by Anh Luong on 4/26/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Storage.h"
#import "ChooserViewController.h"

@class SettingsView;

@protocol SettingsViewDelegate
- (void) colorIsChanged:(UIColor*) color;
@end


@interface SettingsView : UIViewController 
{
	Storage* _settings;
	NSObject<SettingsViewDelegate>* _delegate;
	ChooserViewController* _backgroundColorChooser;
}

@property (assign) NSObject<SettingsViewDelegate>* delegate;
- (id) initWithFrame:(CGRect)frame settings:(Storage*)settings;

@end
