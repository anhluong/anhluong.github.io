//
//  WelcomeView.h
//  LuckyChess
//
//  Created by Anh Luong on 4/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WelcomeView;

@protocol WelcomeViewDelegate
- (void) play;
- (void) setting;
- (void) help;
- (void) menu;
@end


@interface WelcomeView : UIView
{
	UIButton* _play;
	UIButton* _settings;
	UIButton* _help;
	NSObject<WelcomeViewDelegate>* _delegate;
}

@property (assign) NSObject<WelcomeViewDelegate>* delegate;

@end
