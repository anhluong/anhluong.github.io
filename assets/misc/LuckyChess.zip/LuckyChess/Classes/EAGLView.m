//
//  EAGLView.m
//  LuckyChess
//
//  Created by Anh Luong on 4/22/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "EAGLView.h"
#import <OpenGLES/EAGL.h>
#import <OpenGLES/EAGLDrawable.h>
#import <QuartzCore/QuartzCore.h>

#pragma mark Private Interface
@interface EAGLView ()
@end

#pragma mark -
@implementation EAGLView

#pragma mark -
#pragma mark UIView Class Methods
+ (Class) layerClass
{
    return [CAEAGLLayer class];
}

#pragma mark -
#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self == nil)
		return nil;
	
    // Setup an OpenGL rendering layer from the view's CALayer
    CAEAGLLayer* eaglLayer = (CAEAGLLayer*)self.layer;
    eaglLayer.opaque = YES;
    eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
        [NSNumber numberWithBool:NO], 
        kEAGLDrawablePropertyRetainedBacking, 
        kEAGLColorFormatRGBA8, 
        kEAGLDrawablePropertyColorFormat, 
        nil];
    
    // Create an OpenGL rendering context
    _context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
    if (!_context || ![EAGLContext setCurrentContext:_context]) 
        return nil;
    
    // Allocate frame and render buffer IDs
    glGenFramebuffersOES(1, &_viewFramebuffer);
    glGenRenderbuffersOES(1, &_viewRenderbuffer);
    
    // Create frame and render buffers
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, _viewFramebuffer);
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, _viewRenderbuffer);
    [_context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)self.layer];
    glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, _viewRenderbuffer);
    
    // Get size of view from API (should be the same as the frame parameter)
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &_viewportWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &_viewportHeight);
    
    // Create depth buffer
    glGenRenderbuffersOES(1, &_depthRenderbuffer);
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, _depthRenderbuffer);
    glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, _viewportWidth, _viewportHeight);
    glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, _depthRenderbuffer);
    
    // Check for successful creation
    if (glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) 
        return nil;
    
    // Redefine OpenGL state
    glEnable(GL_DEPTH_TEST);
    glEnableClientState(GL_VERTEX_ARRAY);
    
    // Create models
	//TODO: This!
    
    // Start animation
    [NSTimer scheduledTimerWithTimeInterval:1.0f / 60.0f 
        target:self 
        selector:@selector(drawView) 
        userInfo:nil 
        repeats:YES];
    
	return self;
} 

- (void) dealloc
{
    // Deallocate video buffers
    glDeleteFramebuffersOES(1, &_viewFramebuffer);
    _viewFramebuffer = 0;
    glDeleteRenderbuffersOES(1, &_viewRenderbuffer);
    _viewRenderbuffer = 0;
    glDeleteRenderbuffersOES(1, &_depthRenderbuffer);
    _depthRenderbuffer = 0;
    
    [super dealloc];
}

#pragma mark -
#pragma mark EAGLView Methods
- (void) drawView
{
	// Setup OpenGL Context
    [EAGLContext setCurrentContext:_context];
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, _viewFramebuffer);
    glViewport(0, 0, _viewportWidth, _viewportHeight);
    
	// Setup camera
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrthof(-1.0f, 1.0f, -1.5f, 1.5f, -1000.0f, 1000.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
	// Clear frame buffer
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
	// Render
    //TODO: Render something better
    const GLfloat squareVertices[] = 
    {
        -0.5f, -0.5f,
        0.5f,  -0.5f,
        -0.5f,  0.5f,
        0.5f,   0.5f,
    };
    glVertexPointer(2, GL_FLOAT, 0, squareVertices);
    glEnableClientState(GL_VERTEX_ARRAY);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    
	// Present rendered data
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, _viewRenderbuffer);
    [_context presentRenderbuffer:GL_RENDERBUFFER_OES];
}

@end
