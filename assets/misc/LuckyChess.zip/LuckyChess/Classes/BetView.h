//
//  BetView.h
//  LuckyChess
//
//  Created by Anh Luong on 4/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BetView;

@protocol BetViewDelegate
- (void) setting;
- (void) help;
- (void) menu;
@end


@interface BetView : UIView
{
	CGRect _frame;
	UIButton* _menu;
	UIButton* _settings;
	UIButton* _help;
	int dice[3];
	UIImageView* diceImage[3];
	int _player;
	float _playerRedMoney;
	UILabel* _playerRedMoneyLabel;
	UILabel* _playerBlueMoneyLabel;
	float _playerBlueMoney;
	UIImageView* _playerRed;
	UIImageView* _playerBlue;
	NSMutableArray* _moneyPilesR;
	NSMutableArray* _moneyPilesB;
	NSObject<BetViewDelegate>* _delegate;
	UIAlertView* _alert;
	UILabel* _Rlabel[6];
	UILabel* _Blabel[6];
	int numOfPlayers;
}

@property (assign) NSObject<BetViewDelegate>* delegate;
- (void) setNumOfPlayers:(int)num;

@end
