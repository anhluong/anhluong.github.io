//
//  SelectionView.h
//  Colors
//

#import <UIKit/UIKit.h>
@class SelectionView;

@protocol SelectionViewDelegate
@optional - (void) valueSlider:(SelectionView*)valueSlider colorSelected:(UIColor*)color;
@end

//  SelectionView Class
//
//  Allows the selection of the Value component of a color
//  Can be displayed horizontally or vertically
//
@interface SelectionView : UIView 
{
	NSObject<SelectionViewDelegate>* _viewDelegate;
	
	CGRect _sliderRect;
	
	UIColor* _color;
}

@property (assign) NSObject<SelectionViewDelegate>* viewDelegate;
@property (retain) UIColor* color;

@end
