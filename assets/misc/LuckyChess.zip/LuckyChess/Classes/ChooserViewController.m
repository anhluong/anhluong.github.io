//
//  ChooserViewController.m
//  Shapes
//
//  Created by u0533327 on 3/11/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ChooserViewController.h"
#import "ChooserView.h"

#pragma mark -
#pragma mark Private Interface
@interface ChooserViewController ()<ChooserViewDelegate>
@end

#pragma mark -
@implementation ChooserViewController

#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self == nil)
        return nil;
	
	_colorWheel = [[ChooserView alloc] initWithFrame:frame];
	[_colorWheel setBackgroundColor:[UIColor lightGrayColor]];
	_colorWheel.delegate = self;
    
    return self;
}

- (void) dealloc
{
    [super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

#pragma mark -
#pragma mark Methods
- (void) loadView
{
	[self setView:_colorWheel];
}

- (void) setColor:(UIColor*)color
{
	[_colorWheel setPreviousColor:color];
}

- (void) colorChanged:(UIColor*)color
{
	[_delegate colorIsChanged:color];
}

@end
