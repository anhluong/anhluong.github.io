//
//  BetViewController.m
//  LuckyChess
//
//  Created by Anh Luong on 4/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BetViewController.h"

#pragma mark -
#pragma mark Private Interface
@interface BetViewController ()<BetViewDelegate>
@end

#pragma mark -
@implementation BetViewController

#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame settings:(Storage*)settings
{
    self = [super init];
    if (self == nil)
        return nil;
	    
	_frame = frame;
	
    return self;
}

- (void) dealloc
{
    [super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

- (BetView*) contentView
{
	return (BetView*)[self view];
}

#pragma mark -
#pragma mark Methods
- (void) loadView
{
	_betView = [[[BetView alloc] initWithFrame:_frame] autorelease];
	[self setView:_betView];
	_betView.delegate = self;
}

- (void) menu
{
	[_delegate menu];
}

-(void) setting
{
	[_delegate setting];
}

-(void) help
{
	[_delegate help];
}

- (void) setNumOfPlayers:(int)num
{
	[_betView setNumOfPlayers:num];
}

- (void) setBackground:(UIColor*)color
{
	[_betView setBackgroundColor:color];
	[_betView setNeedsLayout];
}

@end
