//
//  BetView.m
//  LuckyChess
//
//  Created by Anh Luong on 4/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BetView.h"

#pragma mark -
#pragma mark Private Interface
@interface BetView ()
@end

#pragma mark -
@implementation BetView

#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self == nil)
        return nil;
	
	[self setBackgroundColor:[UIColor whiteColor]];
	
	_moneyPilesR = [[NSMutableArray alloc] init];
	_moneyPilesB = [[NSMutableArray alloc] init];
	
	for (int i = 0; i < 6; i++)
	{
		[_moneyPilesR addObject:[NSNumber numberWithFloat:0.0f]];
		[_moneyPilesB addObject:[NSNumber numberWithFloat:0.0f]];
	}
	
	_player = 1; //One is red // Two is blue
	
	_playerRedMoney = 10.0f;
	_playerBlueMoney = 10.0f;
	
	_playerRed = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"active.png"]];
	_playerBlue = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"idle.png"]];
	
	_playerRedMoneyLabel = [[UILabel alloc] init];
	_playerBlueMoneyLabel = [[UILabel alloc] init];
	
	_frame = frame;
	
    return self;
}

- (void) dealloc
{
    [super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

- (void) setNumOfPlayers:(int)num
{
	numOfPlayers = num;
	[self setNeedsLayout];
}

#pragma mark -
#pragma mark Methods
#pragma mark Frame
- (CGRect) frameForIndex:(int)i
{
	CGRect rect = CGRectZero;
	
	float width = _frame.size.width;
	float height = _frame.size.height;
	
	if (i < 3)
	{
		rect = CGRectMake(width * (i) / 3,
						  ((height - width * 2 / 3) / 2), 
						  width / 3, 
						  width / 3);
	}
	else
	{
		rect = CGRectMake(width * (i - 3) / 3,
						  ((height - width * 2 / 3) / 2) + width / 3, 
						  width / 3, 
						  width / 3);
	}
	
	return rect;
}

- (CGRect) moneyRDisplayFrameAtIndex:(int)i
{
	CGRect rect = CGRectZero;
	
	float width = _frame.size.width;
	float height = _frame.size.height;
	
	if (i < 3)
	{
		rect = CGRectMake(width * (i * 2) / 6 + width * 0.05f,
						  ((height - width * 2 / 3) / 2), 
						  width * 0.15f, 
						  height * 0.05f);
	}
	else
	{
		rect = CGRectMake(width * ((i - 3) * 2) / 6 + width * 0.125f,
						  ((height - width * 2 / 3) / 2) + width / 3, 
						  width * 0.15f, 
						  height * 0.05f);
	}
	
	return rect;
}

- (CGRect) moneyBDisplayFrameAtIndex:(int)i
{
	CGRect rect = CGRectZero;
	
	float width = _frame.size.width;
	float height = _frame.size.height;
	
	if (i < 3)
	{
		rect = CGRectMake(width * (i * 2) / 6 + width * 0.125f,
						  ((height - width * 2 / 3) / 2) + width / 3 - height * 0.05f, 
						  width * 0.15f, 
						  height * 0.05f);
	}
	else
	{
		rect = CGRectMake(width * ((i - 3) * 2) / 6 + width * 0.05f,
						  ((height - width * 2 / 3) / 2) + width * 2 / 3 - height * 0.05f, 
						  width * 0.15f, 
						  height * 0.05f);
	}
	
	return rect;
}

- (CGRect) frameForDiceAtIndex:(int)i
{
	CGRect rect = CGRectZero;
	
	float width = _frame.size.width;
	float height = _frame.size.height;
	
	rect = CGRectMake(width * (i) / 3 + (width / 3 - width / 5) / 2,
					  (((height - width * 2 / 3) / 2) - width / 5) / 2, 
					  width / 5, 
					  width / 5);
	
	return rect;
}

#pragma mark Image Loader
-(UIImageView*) imageForType:(int)i
{
	UIImageView* image;
	
	switch(i)
	{
		case 0:
		{
			image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"deer.png"]]; break;
		}
		case 1: 
		{
			image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"gourd.png"]]; break;
		}
		case 2:
		{
			image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"rooster.png"]]; break;
		}
		case 3: 
		{
			image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"fish.png"]]; break;
		}
		case 4: 
		{
			image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"crab.png"]]; break;
		}
		case 5: 
		{
			image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shrimp.png"]]; break;
		}
		default: nil;
	}
	
	return image;
}

#pragma mark UIView Override
- (void) layoutSubviews
{	
	for (UIView* sub in [self subviews])
	{
		[sub removeFromSuperview];
	}
	
	for (int i = 0; i < 3; i++)
	{
		UIImageView* image;
		
		image = [self imageForType:dice[i]];
		[image setFrame:[self frameForDiceAtIndex:i]];
		
		[self addSubview:image];
		[image release];
	}
	
	//[_menu removeFromSuperview];
	_menu = [[[UIButton buttonWithType:UIButtonTypeRoundedRect] retain] autorelease];
	[_menu setFrame:CGRectMake(_frame.size.width * 0.80f, _frame.size.height * 0.735f, _frame.size.width * 0.15f, _frame.size.height * 0.05f)];
	[_menu setTitle:@"Menu" forState:UIControlStateNormal];
	[_menu.titleLabel setFont:[UIFont systemFontOfSize:10]];
	[_menu addTarget:self action:@selector(menu) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_menu];
	
	//[_settings removeFromSuperview];
	_settings = [[[UIButton buttonWithType:UIButtonTypeRoundedRect] retain] autorelease];
	[_settings setFrame:CGRectMake(_frame.size.width * 0.80f, _frame.size.height * 0.810f, _frame.size.width * 0.15f, _frame.size.height * 0.05f)];
	[_settings setTitle:@"Settings" forState:UIControlStateNormal];
	[_settings.titleLabel setFont:[UIFont systemFontOfSize:10]];
	[_settings addTarget:self action:@selector(setting) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_settings];
	
	//[_help removeFromSuperview];
	_help = [[[UIButton buttonWithType:UIButtonTypeRoundedRect] retain] autorelease];
	[_help setFrame:CGRectMake(_frame.size.width * 0.80f, _frame.size.height * 0.885f, _frame.size.width * 0.15f, _frame.size.height * 0.05f)];
	[_help setTitle:@"Help" forState:UIControlStateNormal];
	[_help.titleLabel setFont:[UIFont systemFontOfSize:10]];
	[_help addTarget:self action:@selector(help) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_help];
	
	for (int i = 0; i < 6; i++)
	{
		UIImageView* image;
		UILabel* Rlabel;
		UILabel* Blabel;
		
		Rlabel = [[UILabel alloc] initWithFrame:[self moneyRDisplayFrameAtIndex:i]];
		[Rlabel setText:[NSString stringWithFormat:@"$%1.2f", [[_moneyPilesR objectAtIndex:i] floatValue]]];
		[Rlabel setTextColor:[UIColor redColor]];
		[Rlabel setBackgroundColor:[UIColor clearColor]];
		
		if (numOfPlayers == 2)
		{
			Blabel = [[UILabel alloc] initWithFrame:[self moneyBDisplayFrameAtIndex:i]];
			[Blabel setText:[NSString stringWithFormat:@"$%1.2f", [[_moneyPilesB objectAtIndex:i] floatValue]]];
			[Blabel setTextColor:[UIColor blueColor]];
			[Blabel setBackgroundColor:[UIColor clearColor]];
		}
		
		image = [self imageForType:i];
		[image setFrame:[self frameForIndex:i]];
		
		[self addSubview:image];
		[image release];
		[self addSubview:Rlabel];
		[Rlabel release];
		
		if (numOfPlayers == 2)
		{
			[self addSubview:Blabel];
			[Blabel release];
		}
	}
	
	UIButton* roll = [[[UIButton buttonWithType:UIButtonTypeRoundedRect] retain] autorelease];
	[roll setFrame:CGRectMake(_frame.size.width * 1/3 - _frame.size.width * 0.075f, _frame.size.height * 0.5f - _frame.size.height * 0.025f, _frame.size.width * 0.15f, _frame.size.height * 0.05f)];
	[roll setTitle:@"Roll" forState:UIControlStateNormal];
	[roll.titleLabel setFont:[UIFont systemFontOfSize:10]];
	[roll addTarget:self action:@selector(roll) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:roll];
	
	UIButton* clearAll = [[[UIButton buttonWithType:UIButtonTypeRoundedRect] retain] autorelease];
	[clearAll setFrame:CGRectMake(_frame.size.width * 2/3 - _frame.size.width * 0.075f, _frame.size.height * 0.5f - _frame.size.height * 0.025f, _frame.size.width * 0.15f, _frame.size.height * 0.05f)];
	[clearAll setTitle:@"Clear" forState:UIControlStateNormal];
	[clearAll.titleLabel setFont:[UIFont systemFontOfSize:10]];
	[clearAll addTarget:self action:@selector(clear) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:clearAll];
	
	//[_playerRed removeFromSuperview];
	[_playerRed setFrame:CGRectMake((_frame.size.width / 3 - _frame.size.width / 5) / 2,
								   _frame.size.height * 0.735f, 
								   _frame.size.width / 5, 
								   _frame.size.width / 5)];
	[self addSubview:_playerRed];
	
	if (numOfPlayers == 2)
	{
		//[_playerBlue removeFromSuperview];
		[_playerBlue setFrame:CGRectMake(_frame.size.width / 3 + (_frame.size.width / 3 - _frame.size.width / 5) / 2,
										 _frame.size.height * 0.735f, 
										 _frame.size.width / 5, 
										 _frame.size.width / 5)];
		[self addSubview:_playerBlue];
	}
	
	//[_playerRedMoneyLabel removeFromSuperview];
	[_playerRedMoneyLabel setFrame:CGRectMake((_frame.size.width / 3 - _frame.size.width / 5) / 2, _frame.size.height * 0.885f, _frame.size.width / 5, _frame.size.height * 0.05f)];
	[_playerRedMoneyLabel setText:[NSString stringWithFormat:@"$%1.2f", _playerRedMoney]];
	[_playerRedMoneyLabel setTextColor:[UIColor redColor]];
	[_playerRedMoneyLabel setBackgroundColor:[UIColor clearColor]];
	[_playerRedMoneyLabel setTextAlignment:UITextAlignmentCenter];
	[self addSubview:_playerRedMoneyLabel];
	
	if (numOfPlayers == 2)
	{
		//[_playerBlueMoneyLabel removeFromSuperview];
		[_playerBlueMoneyLabel setFrame:CGRectMake(_frame.size.width / 3 + (_frame.size.width / 3 - _frame.size.width / 5) / 2, _frame.size.height * 0.885f, _frame.size.width / 5, _frame.size.height * 0.05f)];
		[_playerBlueMoneyLabel setText:[NSString stringWithFormat:@"$%1.2f", _playerBlueMoney]];
		[_playerBlueMoneyLabel setTextColor:[UIColor blueColor]];
		[_playerBlueMoneyLabel setBackgroundColor:[UIColor clearColor]];
		[_playerBlueMoneyLabel setTextAlignment:UITextAlignmentCenter];
		[self addSubview:_playerBlueMoneyLabel];
	}
}

#pragma mark Response
- (void) playerSel:(int)player
{
	if(player == 1)
	{
		[_playerRed setImage:[UIImage imageNamed:@"active.png"]];
		[_playerBlue setImage:[UIImage imageNamed:@"idle.png"]];
	}
	
	if(player == 2)
	{
		[_playerRed setImage:[UIImage imageNamed:@"idle.png"]];
		[_playerBlue setImage:[UIImage imageNamed:@"active.png"]];
	}
	
	_player = player;
	[self setNeedsLayout];
}

#pragma mark UIResponder Override
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	for(UITouch* touch in touches)
	{
		for(int i = 0; i < 6; i++)
		{
			if(CGRectContainsPoint([self frameForIndex:i], [touch locationInView:self]))
			{
				if(_player == 1 && _playerRedMoney > 0)
				{
					float temp = [[_moneyPilesR objectAtIndex:i] floatValue];
					[_moneyPilesR replaceObjectAtIndex:i withObject:[NSNumber numberWithFloat:(temp + 0.25f)]];
					_playerRedMoney -= 0.25f;
					//[_playerRedMoneyLabel setText:[NSString stringWithFormat:@"$%1.2f", _playerRedMoney]];
					[self setNeedsLayout];
				}
				else if(_player == 2 && _playerBlueMoney > 0)
				{
					float temp = [[_moneyPilesB objectAtIndex:i] floatValue];
					[_moneyPilesB replaceObjectAtIndex:i withObject:[NSNumber numberWithFloat:(temp + 0.25f)]];
					_playerBlueMoney -= 0.25f;
					//[_playerBlueMoneyLabel setText:[NSString stringWithFormat:@"$%1.2f", _playerBlueMoney]];
					[self setNeedsLayout];
				}
				else
				{
					_alert = [[[UIAlertView alloc] initWithTitle:@"Status" message:@"You don't have enough!" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil] autorelease];
					[_alert show];
				}
				break;
			}
			else if(CGRectContainsPoint(CGRectMake((_frame.size.width / 3 - _frame.size.width / 5) / 2,
												   _frame.size.height * 0.735f, 
												   _frame.size.width / 5, 
												   _frame.size.width / 5), [touch locationInView:self]))
			{
				[self playerSel:1];
				break;
			}
			else if(numOfPlayers == 2 && CGRectContainsPoint(CGRectMake(_frame.size.width / 3 + (_frame.size.width / 3 - _frame.size.width / 5) / 2,
												   _frame.size.height * 0.735f, 
												   _frame.size.width / 5, 
												   _frame.size.width / 5), [touch locationInView:self]))
			{
				[self playerSel:2];
				break;
			}
		}
	}
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{

}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	
}

#pragma mark Buttons Actions
- (void) clear
{	
	for (int i = 0; i < 6; i++)
	{
		if(_player == 1)
		{
			_playerRedMoney +=  [[_moneyPilesR objectAtIndex:i] floatValue];
			
			[_moneyPilesR replaceObjectAtIndex:i withObject:[NSNumber numberWithFloat:0.0f]];
			
		}
		else if(_player == 2)
		{
			_playerBlueMoney += [[_moneyPilesB objectAtIndex:i] floatValue];
			
			[_moneyPilesB replaceObjectAtIndex:i withObject:[NSNumber numberWithFloat:0.0f]];
		}
	}
	
	[self setNeedsLayout];
}

- (void) moneyReturn
{
	for(int i = 0; i < 6; i++)
	{
		int multiple = 0;
		
		for(int j = 0; j < 3; j++)
		{
			if(dice[j] == i)
			{
				multiple++;
			}
		}
		
		if(multiple >= 1)
		{
			multiple++;
		}
		
		[_moneyPilesR replaceObjectAtIndex:i withObject:[NSNumber numberWithFloat:([[_moneyPilesR objectAtIndex:i] floatValue] * multiple)]];
		[_moneyPilesB replaceObjectAtIndex:i withObject:[NSNumber numberWithFloat:([[_moneyPilesB objectAtIndex:i] floatValue] * multiple)]];
	}
	
	if(_player == 1)
	{
		_player = 2;
		[self clear];
		_player = 1;
		[self clear];
	}
	else
	{
		_player = 1;
		[self clear];
		_player = 2;
		[self clear];
	}
	
	if(_playerRedMoney <= 0 && _playerBlueMoney <= 0)
	{
		_alert = [[[UIAlertView alloc] initWithTitle:@"Status" message:@"Both Lost!" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil] autorelease];
		[_alert show];
		_playerRedMoney = 10.0f;
		_playerBlueMoney = 10.0f;
	}
	else if(_playerRedMoney <= 0)
	{
		_alert = [[[UIAlertView alloc] initWithTitle:@"Status" message:@"Red Lost!" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil] autorelease];
		[_alert show];
		_playerRedMoney = 10.0f;
		_playerBlueMoney = 10.0f;
	}
	else if(_playerBlueMoney <= 0)
	{
		_alert = [[[UIAlertView alloc] initWithTitle:@"Status" message:@"Blue Lost!" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil] autorelease];
		[_alert show];
		_playerRedMoney = 10.0f;
		_playerBlueMoney = 10.0f;
	}
}

- (void) roll
{
	for(int i = 0; i < 3; i++)
	{
		dice[i] = arc4random() % 6;
	}
	
	[self moneyReturn];
}

- (void) menu
{
	[_delegate menu];
}

-(void) setting
{
	[_delegate setting];
}

-(void) help
{
	[_delegate help];
}

@end
