//
//  WheelView.m
//  Color Chooser
//
//  Created by Anh Luong on 2/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WheelView.h"
#import "CSColor.h"

#pragma mark -
#pragma mark Private Interface
@interface WheelView ()
@end

#pragma mark -
@implementation WheelView

#pragma mark Constructors
- (id) initWithFrame:(CGRect)rect
{
    self = [super initWithFrame:rect];
    if (self == nil)
        return nil;
	
	colorChanged = false;
	
    return self;
}

- (void) dealloc
{
	[super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

- (UIColor*) color
{
    return _color;
}

- (void) setColor:(UIColor*)color
{
    [_color autorelease];
    _color = [color retain];
		
	// Sync all colors
	colorChanged = true;
	[self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (bool) isColorChanged
{
	return colorChanged;
}

- (void) colorChanged
{
	colorChanged = false;
}

#pragma mark -
#pragma mark Methods
- (CGRect) colorFrame:(int)number
{	
	CGRect rect = CGRectZero;
	
	float width = [self bounds].size.width;
	float height = [self bounds].size.height;
	
	if (number <= 4)
	{
		rect = CGRectMake(
						  width * (number - 1) * 0.25f, 
						  height * 0.0f, 
						  width * 0.25f, 
						  height / 3);
	}
	else if (number >= 5 && number <= 8)
	{
		rect = CGRectMake(
						  width * (number - 4 - 1) * 0.25f, 
						  height / 3, 
						  width * 0.25f, 
						  height / 3);
	}
	else
	{
		rect = CGRectMake(
						  width * (number - 8 - 1) * 0.25f, 
						  height * 2 / 3, 
						  width * 0.25f, 
						  height / 3);
	}
	
	return rect;
}

- (UIColor*) colorInFrame:(int)number
{
	float red = 0.0f;
	float green = 0.0f;
	float blue = 0.0f;
	
	if(number <= 3 || number >= 11)
		red = 1.0f;
	else if(number == 4 || number == 10)
		red = 0.5f;
	else
		red = 0.0f;
	
	if(number >= 7 && number <= 11)
		green = 1.0f;
	else if(number == 6 || number == 12)
		green = 0.5f;
	else
		green = 0.0f;
	
	if(number >= 3 && number <= 7)
		blue = 1.0f;
	else if(number == 2 || number == 8)
		blue = 0.5f;
	else
		blue = 0.0f;
	
	return [UIColor colorWithRed:red green:green blue:blue alpha:1.0f];
}

- (UIColor*) colorForX:(CGPoint)point
{
    UIColor* temp = [UIColor clearColor];
	
	for (int i = 1; i <= 12; i++)
	{
		if(CGRectContainsPoint([self colorFrame:i], point))
			return [self colorInFrame:i];
	}
    
    return temp;
}

#pragma mark UIView Overrides
- (void) drawRect:(CGRect)rect
{
	CGContextRef context = UIGraphicsGetCurrentContext();
    
	// Fill background
	CGContextSetFillColorWithColor(context, [[UIColor lightGrayColor] CGColor]);
	CGContextFillRect(context, [self bounds]);
	
	for (int i = 1; i <= 12; i++) 
	{
		// Draw colors
		CGRect rect = [self colorFrame:i];
		CGContextAddEllipseInRect(context, rect);
		CGContextSetFillColorWithColor(context, [[self colorInFrame:i] CGColor]);
		CGContextDrawPath(context, kCGPathFill);
	}
	
	// Draw touch indicator circle in view local coordinates
    CGSize touchEllipseSize = CGSizeMake([self bounds].size.width * 0.1f, [self bounds].size.width * 0.1f);
    CGContextAddEllipseInRect(context, CGRectMake(
												  _touchPoint.x - touchEllipseSize.width * 0.5f, 
												  _touchPoint.y - touchEllipseSize.height * 0.5f, 
												  touchEllipseSize.width, 
												  touchEllipseSize.height));
	CGContextSetStrokeColorWithColor(context, [[UIColor whiteColor] CGColor]);
    CGContextSetFillColorWithColor(context, [[self colorForX:_touchPoint] CGColor]);
    CGContextDrawPath(context, kCGPathFillStroke);

	[self setColor:[self colorForX:_touchPoint]];
}

#pragma mark UIResponder Overrides
- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
    // Store touch point (in view local coordinates)
    _touchPoint = [[touches anyObject] locationInView:self];
    [self setNeedsDisplay];
}

@end
