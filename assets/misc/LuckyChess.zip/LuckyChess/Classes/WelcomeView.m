//
//  WelcomeView.m
//  LuckyChess
//
//  Created by Anh Luong on 4/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WelcomeView.h"

#pragma mark -
#pragma mark Private Interface
@interface WelcomeView ()
@end

#pragma mark -
@implementation WelcomeView

#pragma mark Constructors
- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self == nil)
        return nil;
	
	UIImage* background = [UIImage imageNamed:@"pokerchips.jpg"];
	[self setBackgroundColor:[[UIColor alloc] initWithPatternImage:background]];
	
	UILabel* title = [[UILabel alloc] init];
	[title setFrame:CGRectMake(frame.size.width * 0.125f, frame.size.height * 0.15f, frame.size.width * 0.75f, frame.size.height * 0.15f)];
	[title setBackgroundColor:[UIColor clearColor]];
	[title setText:@"Lucky Chess"];
	title.font = [UIFont fontWithName:@"Zapfino" size:32];
	title.shadowColor = [UIColor blackColor];
	title.textColor = [UIColor blueColor];
	[self addSubview:title];
	
	_play = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
	[_play setFrame:CGRectMake(frame.size.width * 0.25f, frame.size.height * 0.40f, frame.size.width * 0.5f, frame.size.height * 0.10f)];
	[_play setTitle:@"Play" forState:UIControlStateNormal];
	[_play addTarget:self action:@selector(play) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_play];
	
	_settings = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
	[_settings setFrame:CGRectMake(frame.size.width * 0.25f, frame.size.height * 0.60f, frame.size.width * 0.5f, frame.size.height * 0.10f)];
	[_settings setTitle:@"Settings" forState:UIControlStateNormal];
	[_settings addTarget:self action:@selector(setting) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_settings];
	
	_help = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
	[_help setFrame:CGRectMake(frame.size.width * 0.25f, frame.size.height * 0.80f, frame.size.width * 0.5f, frame.size.height * 0.10f)];
	[_help setTitle:@"Help" forState:UIControlStateNormal];
	[_help addTarget:self action:@selector(help) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_help];
    
    return self;
}

- (void) dealloc
{
	[_play release];
    [super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;

#pragma mark -
#pragma mark Methods
- (void) play
{
	[_delegate play];
}

-(void) setting
{
	[_delegate setting];
}

-(void) help
{
	[_delegate help];
}


@end
