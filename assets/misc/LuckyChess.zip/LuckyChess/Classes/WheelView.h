//
//  WheelView.h
//  Color Chooser
//
//  Created by Anh Luong on 2/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSColor.h"

@class WheelView;

@protocol WheelViewDelegate
@optional - (void) wheelView:(WheelView*)wheelView colorChanged:(UIColor*)color;
@end


@interface WheelView : UIControl
{
	NSObject<WheelViewDelegate>* _delegate;
	
	CGPoint _touchPoint;
	
	UIColor* _color;
	
	bool colorChanged;
}

@property (assign) NSObject<WheelViewDelegate>* delegate;
@property (retain) UIColor* color;

- (UIColor*) colorForX:(CGPoint)point;
- (bool) isColorChanged;
- (void) colorChanged;

@end
