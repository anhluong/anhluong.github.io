//
//  EAGLView.h
//  LuckyChess
//
//  Created by Anh Luong on 4/22/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>

@interface EAGLView : UIView 
{
    EAGLContext* _context;
    GLint _viewportWidth;
    GLint _viewportHeight;
	GLuint _viewRenderbuffer;
    GLuint _viewFramebuffer;
    GLuint _depthRenderbuffer;
}

@end
