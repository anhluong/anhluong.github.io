//
//  Storage.m
//  LuckyChess
//
//  Created by Anh Luong on 4/27/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Storage.h"

#pragma mark -
#pragma mark Private Interface
@interface Storage ()
@end

#pragma mark -
@implementation Storage

#pragma mark Constructors
- (id) init
{
    self = [super init];
    if (self == nil)
        return nil;
	
	_numOfPlayers = 1;
	
	_settings = [[NSMutableArray alloc] init];
	
	[_settings addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Players", @"Title", [NSNumber numberWithInt:1], @"Players", nil]];
	[_settings addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"Background", @"Title", 
														 [NSNumber numberWithFloat:1.0f], @"Red", 
														 [NSNumber numberWithFloat:1.0f], @"Blue", 
														 [NSNumber numberWithFloat:1.0f], @"Green",
														 [NSNumber numberWithFloat:1.0f], @"Alpha", nil]];
	
	
	NSArray* buttonNames = [NSArray arrayWithObjects:@"1 Player", @"2 Players", nil];
	_playerSel = [[UISegmentedControl alloc] initWithItems:buttonNames];
	[_playerSel addTarget:self action:@selector(playerSel:) forControlEvents:UIControlEventValueChanged];
	
	//[self setBackground:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f]];
	
    return self;
}

- (void) dealloc
{
    [super dealloc];
}

#pragma mark -
#pragma mark Accessors
@synthesize delegate = _delegate;
@synthesize background = _background;

- (int) numOfPlayers
{
	return _numOfPlayers;
}

#pragma mark -
#pragma mark Methods
- (NSInteger) numberOfSectionsInTableView:(UITableView*)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section
{
	return [_settings count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{	
	UITableViewCell* cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
	
	NSDictionary* currentCell = [_settings objectAtIndex:[indexPath row]];
	
	[[cell textLabel] setText:[currentCell objectForKey:@"Title"]];
	
	if([indexPath row] == 0)
	{
		_playerSel.momentary = TRUE;                               
		_playerSel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		_playerSel.segmentedControlStyle = UISegmentedControlStyleBar;
		_playerSel.frame = CGRectMake(75, 5, 130, 30);
		_playerSel.selectedSegmentIndex = (_numOfPlayers - 1);
		[cell setAccessoryView:_playerSel];
	}
	else if([indexPath row] == 1)
	{
		[cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
	}
	
	return cell;
}

- (void)playerSel:(UISegmentedControl*)sender
{	
	switch(_playerSel.selectedSegmentIndex)
	{
		case 0: _numOfPlayers = 1; break;
		case 1: _numOfPlayers = 2; break;
		default: _numOfPlayers = 2; break;
	}
	//NSLog(@"%i", _numOfPlayers);
	[_delegate playersChanged:_numOfPlayers];
}

@end
