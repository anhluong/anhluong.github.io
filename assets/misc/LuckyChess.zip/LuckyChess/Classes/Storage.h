//
//  Storage.h
//  LuckyChess
//
//  Created by Anh Luong on 4/27/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Storage;

@protocol StorageDelegate
- (void) playersChanged:(int)num;
@end


@interface Storage : UIControl <UITableViewDataSource> 
{
	UIColor* _background;
	int _numOfPlayers;
	UIImage* _image[6];
	UIImage* _playerImage[2];
	NSObject<StorageDelegate>* _delegate;
	NSMutableArray* _settings;
	UISegmentedControl* _playerSel;
}

@property (assign) UIColor* background;
@property (assign) NSObject<StorageDelegate>* delegate;
- (int) numOfPlayers;

@end
